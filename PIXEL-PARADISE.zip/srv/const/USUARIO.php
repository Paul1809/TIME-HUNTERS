<?php

const USUARIO = "usuario";